#ifndef common_H
#define common_H

extern double robot_Y_position_slip;

#endif
