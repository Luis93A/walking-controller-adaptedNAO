/*
 * Copyright (C) 2012 Open Source Robotics Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
*/
#include "common.h"
#include <gazebo/gazebo_config.h>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#define PORT 8090 
#include <pthread.h>

#include <string>

#include <gazebo/gazebo_client.hh>

double Yres = 0;
double robot_Y_position_slip;
int i=0;
int j=0;
/////////////////////////////////////////////////
// Function is called everytime a message is received.
void cb(ConstPosesStampedPtr &_msg)
{  //std::cout << _msg->DebugString();
   ::google::protobuf::int32 sec = _msg->time().sec();
   ::google::protobuf::int32 nsec = _msg->time().nsec();
   //std::cout << "Read time: sec: " << sec << " nsec: " << nsec << std::endl;
    
    
    const ::gazebo::msgs::Pose &pose = _msg->pose();
    std::string name = pose.name();
//    if (name == std::string("my_velodyne")) {
      const ::gazebo::msgs::Vector3d &position = pose.position();
      const ::gazebo::msgs::Quaternion &orientation = pose.orientation();
      
      double x = position.x();
      double robot_Y_position_slip = position.y() - Yres;
      double z = position.z();
      std::cout  << "Yres:   "<< Yres << std::endl;
       //   << " y: " << y << " z: " << z << std::endl;
          
      double x1 = orientation.x();
      double y1 = orientation.y();
      double z1 = orientation.z();
      double w1 = orientation.w();
    //  std::cout << "Read orientation: x: " << x1
      //    << " y: " << y1 << " z: " << z1 << " w: " << w1 << std::endl;
    
     Yres= position.y();
     std::cout  << "Yres:   "<< Yres << std::endl;
     std::cout  << "y:   "<< robot_Y_position_slip << std::endl;
     
//    }

  // Dump the message contents to stdout.
  //std::cout << _msg->DebugString();
}

/////////////////////////////////////////////////
int main(int _argc, char **_argv)
{
  // Load gazebo
  gazebo::client::setup(_argc, _argv);

  // Create our node for communication
  gazebo::transport::NodePtr node(new gazebo::transport::Node());
  node->Init();

  // Listen to Gazebo world_stats topic
  gazebo::transport::SubscriberPtr sub = node->Subscribe("~/pose/info", cb);

  // Busy wait loop...replace with your own code as needed.
  while (true)
    gazebo::common::Time::MSleep(10);

  // Make sure to shut everything down.
  gazebo::client::shutdown();
}
