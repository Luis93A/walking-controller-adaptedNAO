/**
 * @file WalkingModule.cpp
 * @authors Giulio Romualdi <giulio.romualdi@iit.it>
 * @copyright 2018 iCub Facility - Istituto Italiano di Tecnologia
 *            Released under the terms of the LGPLv2.1 or later, see LGPL.TXT
 * @date 2018
 */

// std
#include <iostream>
#include <memory>
#include <cmath>
#include <cstring>
#include <string>
#include <time.h>  
#include <unistd.h>
#include <cstdio>
// YARP
#include <yarp/os/RFModule.h>
#include <yarp/os/BufferedPort.h>
#include <yarp/sig/Vector.h>
#include <yarp/os/LogStream.h>
#include <yarp/os/Port.h>

// iDynTree
#include <iDynTree/Core/VectorFixSize.h>
#include <iDynTree/Core/EigenHelpers.h>
#include <iDynTree/yarp/YARPConversions.h>
#include <iDynTree/yarp/YARPEigenConversions.h>
#include <iDynTree/Model/Model.h>

#include <WalkingControllers/WalkingModule/Module.h>
#include <WalkingControllers/YarpUtilities/Helper.h>
#include <WalkingControllers/StdUtilities/Helper.h>
 
 // change step velocity 

 //to delete later aux test
int ini_yaw_aux =0;
 //to save new orders
iDynTree::Vector2 Axy; //SET GOAL X -> Axy(0) / Y -> Axy(1)
iDynTree::Vector2 aux_control; // control order (0) ; (1) ??
iDynTree::Vector2 erro_n_output_pid; //save YAW error
iDynTree::Vector3 abs_CoM; //save CoM absolute

iDynTree::Vector2 torso_w;
iDynTree::Vector2 torso_tau;

iDynTree::Vector6 Lleg_w;
iDynTree::Vector6 Lleg_tau;

iDynTree::Vector6 Rleg_w;
iDynTree::Vector6 Rleg_tau;

iDynTree::Vector4 Larm_w;
iDynTree::Vector4 Larm_tau;

iDynTree::Vector4 Rarm_w;
iDynTree::Vector4 Rarm_tau;



//joint velocity control
//P
double ang;
double vc;
double previous_m_q = 0;
int doitonce =1;
//PID
double e2, e1, e0, u2, u1, u0;  // variables used in PID computation
double r;  // command
double y;  // plant output
double Kp = 1.01; // proportional gain
double Ki = 0.00;  // integral gain
double Kd = 0.02;  // derivative gain
double N = 20;  // filter coefficients
double Ts = 0.01; // sampling time
double a0 = (1+N*Ts);
double a1 = -(2 + N*Ts);
double a2 = 1;
double b0 = Kp*(1+N*Ts) + Ki*Ts*(1+N*Ts) + Kd*N;
double b1 = -(Kp*(2+N*Ts) + Ki*Ts + 2*Kd*N);
double b2 = Kp + Kd*N;
double ku1 = a1/a0;
double ku2 = a2/a0;
double ke0 = b0/a0;
double ke1 = b1/a0;
double ke2 = b2/a0;



//read robot YAW aux variables 
yarp::os::Bottle in; //subscribe humanoid YAW 
yarp::os::Bottle in1; //subscribe humanoid CoM coords
yarp::os::Bottle in_leftLeg; // w and tau
yarp::os::Bottle in_rightLeg; // w and tau
yarp::os::Bottle in_leftArm; // w and tau
yarp::os::Bottle in_rightArm; // w and tau
yarp::os::Bottle in_torso; // w and tau

yarp::os::Port inPort; // yaw
yarp::os::Port inPort1; // com x y z


yarp::os::Port inPort_leftLeg; // w and tau
yarp::os::Port inPort_rightLeg;
yarp::os::Port inPort_leftArm;
yarp::os::Port inPort_rightArm;
yarp::os::Port inPort_torso;



double trash1, trash2, current_YAW, initial_YAW, CoM_x1, CoM_y1, CoM_z1;
double x_pos_ordered; //setgoal x 
//tick
int tick =101;
using namespace WalkingControllers;


// PID to control humanoid rotation if this slips and diverge from its goal

void pid(void){ // timer interrupt service routine 

e2=e1; e1=e0; u2=u1; u1=u0; // update variables // 
e0 = r - y;  // compute new error
u0 = -ku1*u1 - ku2*u2 + ke0*e0 + ke1*e1 + ke2*e2; // discrete PID algorithm
erro_n_output_pid(0) = e0;
erro_n_output_pid(1) = u0;
//if (u0 > UMAX) u0 = UMAX;  // if we find limitationS, define UMAX and
//if (U0 < UMIN) u0 = UMIN; // UMIN
}


void WalkingModule::propagateTime()
{
    // propagate time
    m_time += m_dT;
}

bool WalkingModule::advanceReferenceSignals()
{
    // check if vector is not initialized
    if(m_leftTrajectory.empty()
       || m_rightTrajectory.empty()
       || m_leftInContact.empty()
       || m_rightInContact.empty()
       || m_DCMPositionDesired.empty()
       || m_DCMVelocityDesired.empty()
       || m_comHeightTrajectory.empty())
    {
        yError() << "[WalkingModule::advanceReferenceSignals] Cannot advance empty reference signals.";
        return false;
    }

    m_rightTrajectory.pop_front();
    m_rightTrajectory.push_back(m_rightTrajectory.back());

    m_leftTrajectory.pop_front();
    m_leftTrajectory.push_back(m_leftTrajectory.back());

    m_rightTwistTrajectory.pop_front();
    m_rightTwistTrajectory.push_back(m_rightTwistTrajectory.back());

    m_leftTwistTrajectory.pop_front();
    m_leftTwistTrajectory.push_back(m_leftTwistTrajectory.back());

    m_rightInContact.pop_front();
    m_rightInContact.push_back(m_rightInContact.back());

    m_leftInContact.pop_front();
    m_leftInContact.push_back(m_leftInContact.back());

    m_isLeftFixedFrame.pop_front();
    m_isLeftFixedFrame.push_back(m_isLeftFixedFrame.back());

    m_DCMPositionDesired.pop_front();
    m_DCMPositionDesired.push_back(m_DCMPositionDesired.back());

    m_DCMVelocityDesired.pop_front();
    m_DCMVelocityDesired.push_back(m_DCMVelocityDesired.back());

    m_comHeightTrajectory.pop_front();
    m_comHeightTrajectory.push_back(m_comHeightTrajectory.back());

    m_comHeightVelocity.pop_front();
    m_comHeightVelocity.push_back(m_comHeightVelocity.back());

    m_isStancePhase.pop_front();
    m_isStancePhase.push_back(m_isStancePhase.back());

    // at each sampling time the merge points are decreased by one.
    // If the first merge point is equal to 0 it will be dropped.
    // A new trajectory will be merged at the first merge point or if the deque is empty
    // as soon as possible.
    if(!m_mergePoints.empty())
    {
        for(auto& mergePoint : m_mergePoints)
            mergePoint--;

        if(m_mergePoints[0] == 0)
            m_mergePoints.pop_front();
    }
    return true;
}

double WalkingModule::getPeriod()
{
    //  period of the module (seconds)
    return m_dT;
}

bool WalkingModule::setRobotModel(const yarp::os::Searchable& rf)
{
    // load the model in iDynTree::KinDynComputations
    std::string model = rf.check("model",yarp::os::Value("model.urdf")).asString();
    std::string pathToModel = yarp::os::ResourceFinder::getResourceFinderSingleton().findFileByName(model);

    yInfo() << "[WalkingModule::setRobotModel] The model is found in: " << pathToModel;

    // only the controlled joints are extracted from the URDF file
    if(!m_loader.loadReducedModelFromFile(pathToModel, m_robotControlHelper->getAxesList()))
    {
        yError() << "[WalkingModule::setRobotModel] Error while loading the model from " << pathToModel;
        return false;
    }
    return true;
}

bool WalkingModule::configure(yarp::os::ResourceFinder& rf)
{
    // module name (used as prefix for opened ports)
    m_useMPC = rf.check("use_mpc", yarp::os::Value(false)).asBool();
    m_useQPIK = rf.check("use_QP-IK", yarp::os::Value(false)).asBool();
    m_useOSQP = rf.check("use_osqp", yarp::os::Value(false)).asBool();
    m_dumpData = rf.check("dump_data", yarp::os::Value(false)).asBool();

    yarp::os::Bottle& generalOptions = rf.findGroup("GENERAL");
    m_dT = generalOptions.check("sampling_time", yarp::os::Value(0.010)).asDouble();
    std::string name;
    if(!YarpUtilities::getStringFromSearchable(generalOptions, "name", name))
    {
        yError() << "[WalkingModule::configure] Unable to get the string from searchable.";
        return false;
    }
    setName(name.c_str());

    m_robotControlHelper = std::make_unique<RobotInterface>();
    yarp::os::Bottle& robotControlHelperOptions = rf.findGroup("ROBOT_CONTROL");
    robotControlHelperOptions.append(generalOptions);
    if(!m_robotControlHelper->configureRobot(robotControlHelperOptions))
    {
        yError() << "[WalkingModule::configure] Unable to configure the robot.";
        return false;
    }

    yarp::os::Bottle& forceTorqueSensorsOptions = rf.findGroup("FT_SENSORS");
    forceTorqueSensorsOptions.append(generalOptions);
    if(!m_robotControlHelper->configureForceTorqueSensors(forceTorqueSensorsOptions))
    {
        yError() << "[WalkingModule::configure] Unable to configure the Force Torque sensors.";
        return false;
    }

    if(!setRobotModel(rf))
    {
        yError() << "[configure] Unable to set the robot model.";
        return false;
    }

    // open RPC port for external command
    std::string rpcPortName = "/" + getName() + "/rpc";
    this->yarp().attachAsServer(this->m_rpcPort);
    if(!m_rpcPort.open(rpcPortName))
    {
        yError() << "[WalkingModule::configure] Could not open" << rpcPortName << " RPC port.";
        return false;
    }

    std::string desiredUnyciclePositionPortName = "/" + getName() + "/goal:i";
    if(!m_desiredUnyciclePositionPort.open(desiredUnyciclePositionPortName))
    {
        yError() << "[WalkingModule::configure] Could not open" << desiredUnyciclePositionPortName << " port.";
        return false;
    }

    // initialize the trajectory planner
    m_trajectoryGenerator = std::make_unique<TrajectoryGenerator>();
    yarp::os::Bottle& trajectoryPlannerOptions = rf.findGroup("TRAJECTORY_PLANNER");
    trajectoryPlannerOptions.append(generalOptions);
    if(!m_trajectoryGenerator->initialize(trajectoryPlannerOptions))
    {
        yError() << "[configure] Unable to initialize the planner.";
        return false;
    }

    if(m_useMPC)
    {
        // initialize the MPC controller
        m_walkingController = std::make_unique<WalkingController>();
        yarp::os::Bottle& dcmControllerOptions = rf.findGroup("DCM_MPC_CONTROLLER");
        dcmControllerOptions.append(generalOptions);
        if(!m_walkingController->initialize(dcmControllerOptions))
        {
            yError() << "[WalkingModule::configure] Unable to initialize the controller.";
            return false;
        }
    }
    else
    {
        // initialize the MPC controller
        m_walkingDCMReactiveController = std::make_unique<WalkingDCMReactiveController>();
        yarp::os::Bottle& dcmControllerOptions = rf.findGroup("DCM_REACTIVE_CONTROLLER");
        dcmControllerOptions.append(generalOptions);
        if(!m_walkingDCMReactiveController->initialize(dcmControllerOptions))
        {
            yError() << "[WalkingModule::configure] Unable to initialize the controller.";
            return false;
        }
    }

    // initialize the ZMP controller
    m_walkingZMPController = std::make_unique<WalkingZMPController>();
    yarp::os::Bottle& zmpControllerOptions = rf.findGroup("ZMP_CONTROLLER");
    zmpControllerOptions.append(generalOptions);
    if(!m_walkingZMPController->initialize(zmpControllerOptions))
    {
        yError() << "[WalkingModule::configure] Unable to initialize the ZMP controller.";
        return false;
    }

    // initialize the inverse kinematics solver
    m_IKSolver = std::make_unique<WalkingIK>();
    yarp::os::Bottle& inverseKinematicsSolverOptions = rf.findGroup("INVERSE_KINEMATICS_SOLVER");
    if(!m_IKSolver->initialize(inverseKinematicsSolverOptions, m_loader.model(),
                               m_robotControlHelper->getAxesList()))
    {
        yError() << "[WalkingModule::configure] Failed to configure the ik solver";
        return false;
    }

    if(m_useQPIK)
    {
        yarp::os::Bottle& inverseKinematicsQPSolverOptions = rf.findGroup("INVERSE_KINEMATICS_QP_SOLVER");
        inverseKinematicsQPSolverOptions.append(generalOptions);
        if(m_useOSQP)
            m_QPIKSolver = std::make_unique<WalkingQPIK_osqp>();
        else
            m_QPIKSolver = std::make_unique<WalkingQPIK_qpOASES>();

        if(!m_QPIKSolver->initialize(inverseKinematicsQPSolverOptions,
                                     m_robotControlHelper->getActuatedDoFs(),
                                     m_robotControlHelper->getVelocityLimits(),
                                     m_robotControlHelper->getPositionUpperLimits(),
                                     m_robotControlHelper->getPositionLowerLimits()))
        {
            yError() << "[WalkingModule::configure] Failed to configure the QP-IK solver (qpOASES)";
            return false;
        }
    }

    // initialize the forward kinematics solver
    m_FKSolver = std::make_unique<WalkingFK>();
    yarp::os::Bottle& forwardKinematicsSolverOptions = rf.findGroup("FORWARD_KINEMATICS_SOLVER");
    forwardKinematicsSolverOptions.append(generalOptions);
    if(!m_FKSolver->initialize(forwardKinematicsSolverOptions, m_loader.model()))
    {
        yError() << "[WalkingModule::configure] Failed to configure the fk solver";
        return false;
    }

    // initialize the linear inverted pendulum model
    m_stableDCMModel = std::make_unique<StableDCMModel>();
    if(!m_stableDCMModel->initialize(generalOptions))
    {
        yError() << "[WalkingModule::configure] Failed to configure the lipm.";
        return false;
    }

    // set PIDs gains
    yarp::os::Bottle& pidOptions = rf.findGroup("PID");
    if (!m_robotControlHelper->configurePIDHandler(pidOptions))
    {
        yError() << "[WalkingModule::configure] Failed to configure the PIDs.";
        return false;
    }

    // configure the retargeting
    yarp::os::Bottle retargetingOptions = rf.findGroup("RETARGETING");
    retargetingOptions.append(generalOptions);
    m_retargetingClient = std::make_unique<RetargetingClient>();
    if (!m_retargetingClient->initialize(retargetingOptions, getName(), m_dT, m_robotControlHelper->getAxesList()))
    {
        yError() << "[WalkingModule::configure] Failed to configure the retargeting";
        return false;
    }

    // initialize the logger
    if(m_dumpData)
    {
        m_walkingLogger = std::make_unique<LoggerClient>();
        yarp::os::Bottle& loggerOptions = rf.findGroup("WALKING_LOGGER");
        if(!m_walkingLogger->configure(loggerOptions, getName()))
        {
            yError() << "[WalkingModule::configure] Unable to configure the logger.";
            return false;
        }
    }

    // time profiler
    m_profiler = std::make_unique<TimeProfiler>();
    m_profiler->setPeriod(round(0.1/ m_dT));
    if(m_useMPC)
        m_profiler->addTimer("MPC");

    m_profiler->addTimer("IK");
    m_profiler->addTimer("Total");

    // initialize some variables
    m_newTrajectoryRequired = false;
    m_newTrajectoryMergeCounter = -1;
    m_robotState = WalkingFSM::Configured;

    m_inertial_R_worldFrame = iDynTree::Rotation::Identity();
    
    // resize variables
    m_qDesired.resize(m_robotControlHelper->getActuatedDoFs());
    m_dqDesired.resize(m_robotControlHelper->getActuatedDoFs());
    

	
    yInfo() << "[WalkingModule::configure] Ready to play!";


    return true;
}

void WalkingModule::reset()
{
    if(m_useMPC)
        m_walkingController->reset();

    m_trajectoryGenerator->reset();

    if(m_dumpData)
        m_walkingLogger->quit();
}

bool WalkingModule::close()
{
    if(m_dumpData)
        m_walkingLogger->quit();

    // restore PID
    m_robotControlHelper->getPIDHandler().restorePIDs();

    // close retargeting ports
    m_retargetingClient->close();

    // close the ports
    m_rpcPort.close();
    m_desiredUnyciclePositionPort.close();

    // close the connection with robot
    if(!m_robotControlHelper->close())
    {
        yError() << "[WalkingModule::close] Unable to close the connection with the robot.";
        return false;
    }

    // clear all the pointer
    m_trajectoryGenerator.reset(nullptr);
    m_walkingController.reset(nullptr);
    m_walkingZMPController.reset(nullptr);
    m_IKSolver.reset(nullptr);
    m_QPIKSolver.reset(nullptr);
    m_FKSolver.reset(nullptr);
    m_stableDCMModel.reset(nullptr);

    return true;
}

bool WalkingModule::solveQPIK(const std::unique_ptr<WalkingQPIK>& solver, const iDynTree::Position& desiredCoMPosition,
                              const iDynTree::Vector3& desiredCoMVelocity,
                              const iDynTree::Rotation& desiredNeckOrientation,
                              iDynTree::VectorDynSize &output)
{
    bool ok = true;
    solver->setPhase(m_isStancePhase.front());
    ok &= solver->setRobotState(*m_FKSolver);
    solver->setDesiredNeckOrientation(desiredNeckOrientation.inverse());

    solver->setDesiredFeetTransformation(m_leftTrajectory.front(),
                                         m_rightTrajectory.front());

    solver->setDesiredFeetTwist(m_leftTwistTrajectory.front(),
                                m_rightTwistTrajectory.front());

    solver->setDesiredCoMVelocity(desiredCoMVelocity);
    solver->setDesiredCoMPosition(desiredCoMPosition);

    // TODO probably the problem can be written locally w.r.t. the root or the base
    solver->setDesiredHandsTransformation(m_FKSolver->getHeadToWorldTransform() * m_retargetingClient->leftHandTransform(),
                                          m_FKSolver->getHeadToWorldTransform() * m_retargetingClient->rightHandTransform());

    ok &= solver->setDesiredRetargetingJoint(m_retargetingClient->jointValues());

    // set jacobians
    iDynTree::MatrixDynSize jacobian, comJacobian;
    jacobian.resize(6, m_robotControlHelper->getActuatedDoFs() + 6);
    comJacobian.resize(3, m_robotControlHelper->getActuatedDoFs() + 6);

    ok &= m_FKSolver->getLeftFootJacobian(jacobian);
    ok &= solver->setLeftFootJacobian(jacobian);

    ok &= m_FKSolver->getRightFootJacobian(jacobian);
    ok &= solver->setRightFootJacobian(jacobian);

    ok &= m_FKSolver->getNeckJacobian(jacobian);
    ok &= solver->setNeckJacobian(jacobian);

    ok &= m_FKSolver->getCoMJacobian(comJacobian);
    solver->setCoMJacobian(comJacobian);

    ok &= m_FKSolver->getLeftHandJacobian(jacobian);
    ok &= solver->setLeftHandJacobian(jacobian);

    ok &= m_FKSolver->getRightHandJacobian(jacobian);
    ok &= solver->setRightHandJacobian(jacobian);

    if(!ok)
    {
        yError() << "[WalkingModule::solveQPIK] Error while setting the jacobians.";
        return false;
    }

    if(!solver->solve())
    {
        yError() << "[WalkingModule::solveQPIK] Unable to solve the QP-IK problem.";
        return false;
    }

    output = solver->getDesiredJointVelocities();

    return true;
}

bool WalkingModule::updateModule()
{
    std::lock_guard<std::mutex> guard(m_mutex);
    
    //read Inertial data from topic /nao/inertial
    for(static bool first = true;first;first=false){
	    double time_spent = 0.0;
	    yarp::os::Network yarp;
	    
	    
	    // yarp::os::Port inPort;// yarp::os::Bottle in;
	    inPort.open("/nao/imu/yaw");
	    yarp.connect("/nao/inertial", "/nao/imu/yaw");
	    
	    inPort.read(in);
	std::string a; 
	//double trash1, trash2, current_YAW, initial_YAW;
	a = in.toString().c_str();
	char* b = new char [a.length()+1];
	std::strcpy (b,a.c_str());
	int counter =1;
	char *ptr =std::strtok (b, " ");
	
	//discard pitch roll, look at YAW only
	trash1 = atof(ptr);
	ptr = strtok(NULL, " ");
	trash2 =atof(ptr);
	ptr = strtok(NULL, " ");
	initial_YAW =atof(ptr);
	
	//read gazebo x y z CoM
	inPort1.open("/nao/CoM/xyz:o");
	yarp.connect("/nao/CoMInWorld:o", "/nao/CoM/xyz:o");
	
	// read robot joint taw and angular velocity
	inPort_leftLeg.open("/nao/leftLeg/stateExt1:o");
	yarp.connect("/nao/leftLeg/stateExt:o", "/nao/leftLeg/stateExt1:o");
	
	inPort_rightLeg.open("/nao/rightLeg/stateExt1:o");
	yarp.connect("/nao/rightLeg/stateExt:o", "/nao/rightLeg/stateExt1:o");
	
	inPort_rightArm.open("/nao/rightArm/stateExt1:o");
	yarp.connect("/nao/rightArm/stateExt:o", "/nao/rightArm/stateExt1:o");
	
	inPort_leftArm.open("/nao/leftArm/stateExt1:o");
	yarp.connect("/nao/leftArm/stateExt:o", "/nao/leftArm/stateExt1:o");
	
	inPort_torso.open("/nao/torso/stateExt1:o");
	yarp.connect("/nao/torso/stateExt:o", "/nao/torso/stateExt1:o");
	
    }
	 	
 
   
    
    if(m_robotState == WalkingFSM::Preparing)
    {

        if(!m_robotControlHelper->getFeedbacksRaw(100))
            {
                yError() << "[updateModule] Unable to get the feedback.";
                return false;
            }

        bool motionDone = false;
        if(!m_robotControlHelper->checkMotionDone(motionDone))
        {
            yError() << "[WalkingModule::updateModule] Unable to check if the motion is done";
            yInfo() << "[WalkingModule::updateModule] Try to prepare again";
            reset();
            m_robotState = WalkingFSM::Stopped;
            return true;
        }
        if(motionDone)
        {
            // send the reference again in order to reduce error
            if(!m_robotControlHelper->setDirectPositionReferences(m_qDesired))
            {
                yError() << "[prepareRobot] Error while setting the initial position using "
                         << "POSITION DIRECT mode.";
                yInfo() << "[WalkingModule::updateModule] Try to prepare again";
                //test print info
                
                reset();
                m_robotState = WalkingFSM::Stopped;
                return true;
            }
	     
            yarp::sig::Vector buffer(m_qDesired.size());
            iDynTree::toYarp(m_qDesired, buffer);
            // instantiate Integrator object

            yarp::sig::Matrix jointLimits(m_robotControlHelper->getActuatedDoFs(), 2);
            for(int i = 0; i < m_robotControlHelper->getActuatedDoFs(); i++)
            {
                jointLimits(i, 0) = m_robotControlHelper->getPositionLowerLimits()(i);
                jointLimits(i, 1) = m_robotControlHelper->getPositionUpperLimits()(i);
            }
            m_velocityIntegral = std::make_unique<iCub::ctrl::Integrator>(m_dT, buffer, jointLimits);

            // reset the models
            m_walkingZMPController->reset(m_DCMPositionDesired.front());
            m_stableDCMModel->reset(m_DCMPositionDesired.front());

            // reset the retargeting
            if(!m_robotControlHelper->getFeedbacks(100))
            {
                yError() << "[WalkingModule::updateModule] Unable to get the feedback.";
                return false;
            }

            if(!updateFKSolver())
            {
                yError() << "[WalkingModule::updateModule] Unable to update the FK solver.";
                return false;
            }

            if(!m_retargetingClient->reset(*m_FKSolver))
            {
                yError() << "[WalkingModule::updateModule] Unable to reset the retargeting client.";
                return false;

            }


            m_robotState = WalkingFSM::Prepared;

            yInfo() << "[WalkingModule::updateModule] The robot is prepared.";
        }
    }
    else if(m_robotState == WalkingFSM::Walking)
    {
        iDynTree::Vector2 measuredZMP;

        bool resetTrajectory = false;

        m_profiler->setInitTime("Total");

        // check desired planner input
        yarp::sig::Vector* desiredUnicyclePosition = nullptr;
        desiredUnicyclePosition = m_desiredUnyciclePositionPort.read(false);
        if(desiredUnicyclePosition != nullptr)
            if(!setPlannerInput((*desiredUnicyclePosition)(0), (*desiredUnicyclePosition)(1)))
            {
                yError() << "[WalkingModule::updateModule] Unable to set the planner input";
                return false;
            }

        // if a new trajectory is required check if its the time to evaluate the new trajectory or
        // the time to attach new one
        if(m_newTrajectoryRequired)
        {
            // when we are near to the merge point the new trajectory is evaluated
            if(m_newTrajectoryMergeCounter == 20)
            {

                double initTimeTrajectory;
                initTimeTrajectory = m_time + m_newTrajectoryMergeCounter * m_dT;

                iDynTree::Transform measuredTransform = m_isLeftFixedFrame.front() ?
                    m_rightTrajectory[m_newTrajectoryMergeCounter] :
                    m_leftTrajectory[m_newTrajectoryMergeCounter];

                // ask for a new trajectory
                if(!askNewTrajectories(initTimeTrajectory, !m_isLeftFixedFrame.front(),
                                       measuredTransform, m_newTrajectoryMergeCounter,
                                       m_desiredPosition))
                {
                    yError() << "[WalkingModule::updateModule] Unable to ask for a new trajectory.";
                    return false;
                }
            }

            if(m_newTrajectoryMergeCounter == 2)
            {
                if(!updateTrajectories(m_newTrajectoryMergeCounter))
                {
                    yError() << "[WalkingModule::updateModule] Error while updating trajectories. They were not computed yet.";
                    return false;
                }
                m_newTrajectoryRequired = false;
                resetTrajectory = true;
            }

            m_newTrajectoryMergeCounter--;
        }

        if (m_robotControlHelper->getPIDHandler().usingGainScheduling())
        {
            if (!m_robotControlHelper->getPIDHandler().updatePhases(m_leftInContact, m_rightInContact, m_time))
            {
                yError() << "[WalkingModule::updateModule] Unable to get the update PID.";
                return false;
            }
        }

        // get feedbacks and evaluate useful quantities
        if(!m_robotControlHelper->getFeedbacks(100))
        {
            yError() << "[WalkingModule::updateModule] Unable to get the feedback.";
            return false;
        }

        // if the retargeting is not in the approaching phase we can set the stance/walking phase
        if(!m_retargetingClient->isApproachingPhase())
        {
            auto retargetingPhase = m_isStancePhase.front() ? RetargetingClient::Phase::stance : RetargetingClient::Phase::walking;
            m_retargetingClient->setPhase(retargetingPhase);
        }

        m_retargetingClient->getFeedback();

        if(!updateFKSolver())
        {
            yError() << "[WalkingModule::updateModule] Unable to update the FK solver.";
            return false;
        }

        if(!evaluateZMP(measuredZMP))
        {
            yError() << "[WalkingModule::updateModule] Unable to evaluate the ZMP.";
            return false;
        }

        // evaluate 3D-LIPM reference signal
        m_stableDCMModel->setInput(m_DCMPositionDesired.front());
        if(!m_stableDCMModel->integrateModel())
        {
            yError() << "[WalkingModule::updateModule] Unable to propagate the 3D-LIPM.";
            return false;
        }

        // DCM controller
        if(m_useMPC)
        {
            // Model predictive controller
            m_profiler->setInitTime("MPC");
            if(!m_walkingController->setConvexHullConstraint(m_leftTrajectory, m_rightTrajectory,
                                                             m_leftInContact, m_rightInContact))
            {
                yError() << "[WalkingModule::updateModule] unable to evaluate the convex hull.";
                return false;
            }

            if(!m_walkingController->setFeedback(m_FKSolver->getDCM()))
            {
                yError() << "[WalkingModule::updateModule] unable to set the feedback.";
                return false;
            }

            if(!m_walkingController->setReferenceSignal(m_DCMPositionDesired, resetTrajectory))
            {
                yError() << "[WalkingModule::updateModule] unable to set the reference Signal.";
                return false;
            }

            if(!m_walkingController->solve())
            {
                yError() << "[WalkingModule::updateModule] Unable to solve the problem.";
                return false;
            }

            m_profiler->setEndTime("MPC");
        }
        else
        {
            m_walkingDCMReactiveController->setFeedback(m_FKSolver->getDCM());
            m_walkingDCMReactiveController->setReferenceSignal(m_DCMPositionDesired.front(),
                                                               m_DCMVelocityDesired.front());

            if(!m_walkingDCMReactiveController->evaluateControl())
            {
                yError() << "[WalkingModule::updateModule] Unable to evaluate the DCM control output.";
                return false;
            }
        }

        // inner COM-ZMP controller
        // if the the norm of desired DCM velocity is lower than a threshold then the robot
        // is stopped
        m_walkingZMPController->setPhase(m_isStancePhase.front());

        iDynTree::Vector2 desiredZMP;
        if(m_useMPC)
            desiredZMP = m_walkingController->getControllerOutput();
        else
            desiredZMP = m_walkingDCMReactiveController->getControllerOutput();

        // set feedback and the desired signal
        m_walkingZMPController->setFeedback(measuredZMP, m_FKSolver->getCoMPosition());
        m_walkingZMPController->setReferenceSignal(desiredZMP, m_stableDCMModel->getCoMPosition(),
                                                   m_stableDCMModel->getCoMVelocity());

        if(!m_walkingZMPController->evaluateControl())
        {
            yError() << "[WalkingModule::updateModule] Unable to evaluate the ZMP control output.";
            return false;
        }

        iDynTree::Vector2 outputZMPCoMControllerPosition, outputZMPCoMControllerVelocity;
        if(!m_walkingZMPController->getControllerOutput(outputZMPCoMControllerPosition,
                                                        outputZMPCoMControllerVelocity))
        {
            yError() << "[WalkingModule::updateModule] Unable to get the ZMP controller output.";
            return false;
        }

        // inverse kinematics
        m_profiler->setInitTime("IK");

        iDynTree::Position desiredCoMPosition;
        desiredCoMPosition(0) = outputZMPCoMControllerPosition(0);
        desiredCoMPosition(1) = outputZMPCoMControllerPosition(1);
        desiredCoMPosition(2) = m_retargetingClient->comHeight();
        //aux, to comment later
       // yInfo() << "desired com pos x:  " << desiredCoMPosition(0) << "desired com pos y: " << desiredCoMPosition(1);

        iDynTree::Vector3 desiredCoMVelocity;
        desiredCoMVelocity(0) = outputZMPCoMControllerVelocity(0);
        desiredCoMVelocity(1) = outputZMPCoMControllerVelocity(1);
        desiredCoMVelocity(2) = m_retargetingClient->comHeightVelocity();

        // evaluate desired neck transformation
        double yawLeft = m_leftTrajectory.front().getRotation().asRPY()(2);
        double yawRight = m_rightTrajectory.front().getRotation().asRPY()(2);

        double meanYaw = std::atan2(std::sin(yawLeft) + std::sin(yawRight),
                                    std::cos(yawLeft) + std::cos(yawRight));
        iDynTree::Rotation yawRotation, modifiedInertial;

       // yInfo() << "desired meanyaw:  " << meanYaw;
	//test 
	//meanYaw = 0;
        yawRotation = iDynTree::Rotation::RotZ(meanYaw);
 
        
        yawRotation = yawRotation.inverse();

        modifiedInertial = yawRotation * m_inertial_R_worldFrame;
        
        
        
        
        
        

	inPort_leftLeg.read(in_leftLeg);
	inPort_rightLeg.read(in_rightLeg);
	inPort_leftArm.read(in_leftArm);
	inPort_rightArm.read(in_rightArm);
	inPort_torso.read(in_torso);
        
        //yarp::sig::Vector* joint_state_LL = leftLeg_joint_state.read();
        
        
        std::string input_ll = "(%f %f %f %f %f ) [ok] (%f %f %f %f %f ) [ok] (%f %f %f %f %f ) [ok] (%f %f %f %f %f ) %*s (%f %f %f %f %f ) %*s (%f %f %f %f %f ) %*s (%f %f %f %f %f ) [ok] (%f %f %f %f %f ) [ok] (%f %f %f %f %f ) [ok] (%d %d %d %d %d ) [ok] (%d %d %d %d %d ) [ok]";
        
        std::string input_rl= input_ll;
        std::string input_la= input_ll;
        std::string input_ra= input_ll;
        
        std::string input_torso = "(%f %f ) [ok] (%f %f ) [ok] (%f %f ) [ok] (%f %f ) %*s (%f %f ) %*s (%f %f ) %*s (%f %f ) [ok] (%f %f ) [ok] (%f %f ) [ok] (%d %d ) [ok] (%d %d ) [ok]";
          
        
         
        float values[45]; float values_rl[45]; float values_la[45]; float values_ra[45]; float values_t[45];
        
        int int_values[10];

        int count = sscanf(in_leftLeg.toString().c_str(), input_ll.c_str(), &values[0], &values[1], &values[2], &values[3], &values[4], &values[5], &values[6], &values[7], &values[8], &values[9], &values[10], &values[11], &values[12], &values[13], &values[14], &values[15], &values[16], &values[17], &values[18], &values[19], &values[20], &values[21], &values[22], &values[23], &values[24], &values[25], &values[26], &values[27], &values[28], &values[29], &values[30], &values[31], &values[32], &values[33], &values[34], &values[35], &values[36], &values[37], &values[38], &values[39], &values[40], &values[41], &values[42], &values[43], &values[44], &int_values[0], &int_values[1], &int_values[2], &int_values[3], &int_values[4], &int_values[5], &int_values[6], &int_values[7], &int_values[8], &int_values[9]);
    
        
	int count1 = sscanf(in_rightLeg.toString().c_str(), input_rl.c_str(), &values_rl[0], &values_rl[1], &values_rl[2], &values_rl[3], &values_rl[4], &values_rl[5], &values_rl[6], &values_rl[7], &values_rl[8], &values_rl[9], &values_rl[10], &values_rl[11], &values_rl[12], &values_rl[13], &values_rl[14], &values_rl[15], &values_rl[16], &values_rl[17], &values_rl[18], &values_rl[19], &values_rl[20], &values_rl[21], &values_rl[22], &values_rl[23], &values_rl[24], &values_rl[25], &values_rl[26], &values_rl[27], &values_rl[28], &values_rl[29], &values_rl[30], &values_rl[31], &values_rl[32], &values_rl[33], &values_rl[34], &values_rl[35], &values_rl[36], &values_rl[37], &values_rl[38], &values_rl[39], &values_rl[40], &values_rl[41], &values_rl[42], &values_rl[43], &values_rl[44], &int_values[0], &int_values[1], &int_values[2], &int_values[3], &int_values[4], &int_values[5], &int_values[6], &int_values[7], &int_values[8], &int_values[9]);

	int count2 = sscanf(in_rightArm.toString().c_str(), input_ra.c_str(), &values_ra[0], &values_ra[1], &values_ra[2], &values_ra[3], &values_ra[4], &values_ra[5], &values_ra[6], &values_ra[7], &values_ra[8], &values_ra[9], &values_ra[10], &values_ra[11], &values_ra[12], &values_ra[13], &values_ra[14], &values_ra[15], &values_ra[16], &values_ra[17], &values_ra[18], &values_ra[19], &values_ra[20], &values_ra[21], &values_ra[22], &values_ra[23], &values_ra[24], &values_ra[25], &values_ra[26], &values_ra[27], &values_ra[28], &values_ra[29], &values_ra[30], &values_ra[31], &values_ra[32], &values_ra[33], &values_ra[34], &values_ra[35], &values_ra[36], &values_ra[37], &values_ra[38], &values_ra[39], &values_ra[40], &values_ra[41], &values_ra[42], &values_ra[43], &values_ra[44], &int_values[0], &int_values[1], &int_values[2], &int_values[3], &int_values[4], &int_values[5], &int_values[6], &int_values[7], &int_values[8], &int_values[9]);

	int count4 = sscanf(in_torso.toString().c_str(), input_torso.c_str(), &values_t[0], &values_t[1], &values_t[2], &values_t[3], &values_t[4], &values_t[5], &values_t[6], &values_t[7], &values_t[8], &values_t[9], &values_t[10], &values_t[11], &values_t[12], &values_t[13], &values_t[14], &values_t[15], &values_t[16], &values_t[17], &int_values[0], &int_values[1], &int_values[2], &int_values[3]);


	int count3 = sscanf(in_leftArm.toString().c_str(), input_la.c_str(), &values_la[0], &values_la[1], &values_la[2], &values_la[3], &values_la[4], &values_la[5], &values_la[6], &values_la[7], &values_la[8], &values_la[9], &values_la[10], &values_la[11], &values_la[12], &values_la[13], &values_la[14], &values_la[15], &values_la[16], &values_la[17], &values_la[18], &values_la[19], &values_la[20], &values_la[21], &values_la[22], &values_la[23], &values_la[24], &values_la[25], &values_la[26], &values_la[27], &values_la[28], &values_la[29], &values_la[30], &values_la[31], &values_la[32], &values_la[33], &values_la[34], &values_la[35], &values_la[36], &values_la[37], &values_la[38], &values_la[39], &values_la[40], &values_la[41], &values_la[42], &values_la[43], &values_la[44], &int_values[0], &int_values[1], &int_values[2], &int_values[3], &int_values[4], &int_values[5], &int_values[6], &int_values[7], &int_values[8], &int_values[9]);
	
	

                                      
                                      
                                                              
	torso_w(0)= values_t[2];
	torso_w(1)= values_t[3];
	
	torso_tau(0)=values_t[12];
	torso_tau(1)=values_t[13];

	Lleg_w(0)=values[5];
	Lleg_w(1)=values[6] ;
	Lleg_w(2)=values[7];
	Lleg_w(3)=values[8];
	Lleg_w(4)=values[9];
	Lleg_w(5)= 0;
	
	Lleg_tau(0)=values[30];
	Lleg_tau(1)=values[31];
	Lleg_tau(2)=values[32];
	Lleg_tau(3)=values[33];
	Lleg_tau(4)=values[34];
	Lleg_tau(5)= 0;

	Rleg_w(0)=values_rl[5];
	Rleg_w(1)=values_rl[6];
	Rleg_w(2)=values_rl[7];
	Rleg_w(3)=values_rl[8];
	Rleg_w(4)=values_rl[9];
	Rleg_w(5)= 0;
	
	Rleg_tau(0)=values_rl[30] ;
	Rleg_tau(1)=values_rl[31];
	Rleg_tau(2)=values_rl[32];
	Rleg_tau(3)=values_rl[33];
	Rleg_tau(4)=values_rl[34];
	Rleg_tau(5)= 0;

	Larm_w(0)=values_la[5] ;
	Larm_w(1)=values_la[6];
	Larm_w(2)=values_la[7];
	Larm_w(3)=values_la[8];
	
	Larm_tau(0)=values_la[30];
	Larm_tau(1)=values_la[31];
	Larm_tau(2)=values_la[32] ;
	Larm_tau(3)=values_la[33];

	Rarm_w(0)=values_ra[5];
	Rarm_w(1)=values_ra[6];
	Rarm_w(2)=values_ra[7];
	Rarm_w(3)=values_ra[8];
	
	Rarm_tau(0)= values_ra[30];
	Rarm_tau(1)= values_ra[31];
	Rarm_tau(2)= values_ra[32];
	Rarm_tau(3)= values_ra[33];
	
	
	
	
	
	
	inPort1.read(in1);
	std::string a1; 
	a1 = in1.toString().c_str();
	char* b1 = new char [a1.length()+1];
	std::strcpy (b1,a1.c_str());
	char *ptr1 =std::strtok (b1, " ");
	CoM_x1 = atof(ptr1);
	ptr1 = strtok(NULL, " ");
	CoM_y1 =atof(ptr1);
	ptr1 = strtok(NULL, " ");
	CoM_z1 =atof(ptr1);
	//yInfo() << "x:  " << CoM_x1 << "y:  " << CoM_y1 << "z:  " << CoM_z1;
	
	abs_CoM(0) = CoM_x1;
	abs_CoM(1) = CoM_y1;
	abs_CoM(2) = CoM_z1;
	
       
        
        //read IMU robot YAW angle
	inPort.read(in);
	std::string a; 
	//double trash1, trash2, yaww;
	a = in.toString().c_str();
	char* b = new char [a.length()+1];
	std::strcpy (b,a.c_str());
	int counter =1;
	char *ptr =std::strtok (b, " ");
	
	//discard pitch roll, look at YAW only
	trash1 = atof(ptr); ptr = strtok(NULL, " "); trash2 =atof(ptr); ptr = strtok(NULL, " ");
	current_YAW =atof(ptr);
        Axy(0) = x_pos_ordered;
	aux_control(0) = 0;
	
	//what happens if robot slip and loses its innitial direction,
	//with PID
	
	r = initial_YAW;
	y = current_YAW;
	pid();
	
	/*
	if(desiredCoMPosition(0) > 0.45){
		Kp = 0.99; // proportional gain
		Ki = 0.02;  // integral gain
		Kd = 0.01;} 
		
	if(desiredCoMPosition(0) > 0.95){
		Kp = 1.015; // proportional gain
		Ki = 0.02;  // integral gain
		Kd = 0.01;} 
		
	if(desiredCoMPosition(0) > 1.45){
		Kp = 1.04; // proportional gain
		Ki = 0.02;  // integral gain
		Kd = 0.01;} 
	*/	

	
	if(ini_yaw_aux == 1 and x_pos_ordered-desiredCoMPosition(0) > 0.05){
	    ang= u0*(3.1415/180);
	    setPlannerInput((x_pos_ordered-desiredCoMPosition(0)), ((((x_pos_ordered-desiredCoMPosition(0))*sin(ang))))); 
	   // yInfo() << "e0"<< e0 << "u0:  "<< u0 << "Y value" << (-(((x_pos_ordered-desiredCoMPosition(0))*sin(ang)))) << "angle" << ang;
	//yInfo() << "setPlannerInput(" << x_pos_ordered-desiredCoMPosition(0) << "," << ((((x_pos_ordered-desiredCoMPosition(0))*sin(ang)))) << ")" ;
//	yInfo() << desiredCoMPosition(0);
	}

	
	
	
	
	
	//without PID
	
	
	/*
	
	if((current_YAW - initial_YAW < -0.5 or current_YAW - initial_YAW > 0.5 ) ){
		
		if((desiredCoMPosition(0) < x_pos_ordered-0.03) and tick > 1){
		
			double ang;
			ang= (current_YAW-initial_YAW)*(3.14/180);
			Axy(0)= x_pos_ordered-desiredCoMPosition(0);
			
			Axy(1)= -(x_pos_ordered-desiredCoMPosition(0))*sin(ang);
	               aux_control(0) = 1;	
			setPlannerInput((x_pos_ordered-desiredCoMPosition(0)), (-(((x_pos_ordered-desiredCoMPosition(0))*sin(ang))))); 
			tick = 0;
			//yInfo() << "CORRIGIRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR";
		} 
		
		//yInfo() << "Current Yaw:  " << current_YAW << "initial_YAW:  " << initial_YAW << "x:  " << x_pos_ordered;
	
	} //initial_YAW=current_YAW; }
        tick++;
        //yInfo() << tick;
        
        */
        
        
        if(m_useQPIK)
        {
            // integrate dq because velocity control mode seems not available
            yarp::sig::Vector bufferVelocity(m_robotControlHelper->getActuatedDoFs());
            yarp::sig::Vector bufferPosition(m_robotControlHelper->getActuatedDoFs());

            if(!m_FKSolver->setInternalRobotState(m_qDesired, m_dqDesired))
            {
                yError() << "[WalkingModule::updateModule] Unable to set the internal robot state.";
                return false;
            }

            if(!solveQPIK(m_QPIKSolver, desiredCoMPosition,
                          desiredCoMVelocity,
                          yawRotation, m_dqDesired))
            {
                yError() << "[WalkingModule::updateModule] Unable to solve the QP problem with osqp.";
                return false;
            }

            iDynTree::toYarp(m_dqDesired, bufferVelocity);

            bufferPosition = m_velocityIntegral->integrate(bufferVelocity);
            iDynTree::toiDynTree(bufferPosition, m_qDesired);

            if(!m_FKSolver->setInternalRobotState(m_robotControlHelper->getJointPosition(),
                                                  m_robotControlHelper->getJointVelocity()))
            {
                yError() << "[WalkingModule::updateModule] Unable to set the internal robot state.";
                return false;
            }

        }
        else
        {
            if(m_IKSolver->usingAdditionalRotationTarget())
            {
                if(!m_IKSolver->updateIntertiaToWorldFrameRotation(modifiedInertial))
                {
                    yError() << "[WalkingModule::updateModule] Error updating the inertia to world frame rotation.";
                    return false;
                }

                if(!m_IKSolver->setFullModelFeedBack(m_robotControlHelper->getJointPosition()))
                {
                    yError() << "[WalkingModule::updateModule] Error while setting the feedback to the inverse Kinematics.";
                    return false;
                }

                if(!m_IKSolver->computeIK(m_leftTrajectory.front(), m_rightTrajectory.front(),
                                          desiredCoMPosition, m_qDesired))
                {
                    yError() << "[WalkingModule::updateModule] Error during the inverse Kinematics iteration.";
                    return false;
                }
            }
        }
        m_profiler->setEndTime("IK");
        //yInfo() << "desiredddddddd coords " << m_qDesired[13];
	//yInfo() << "desiredddddddd coords " << m_qDesired[14];
	//yInfo() << "desiredddddddd coords " << m_qDesired[15];
	//m_qDesired[16] = 0;
	//m_qDesired[15] = 0;
	//m_qDesired[19] = 0;
	//m_qDesired[20] = 0;
	
	if(previous_m_q.size() == m_qDesired.size())
	{
	    for (int i=0; i< m_qDesired.size(); i++)
	    {
	    	auto v =std::abs(m_qDesired[i]-previous_m_q[i])/0.05;
	    	if(v > 4.36)
	    	{
	    	    yError() << "Oh no! Velocity" << v << "index" << i << "Djoint" << m_qDesired[i] << "previousJoint" << previous_m_q[i] << "time" << m_time;
	    	    return false;
	    	}
	     }
	}
	previous_m_q = m_qDesired;

	
        if(!m_robotControlHelper->setDirectPositionReferences(m_qDesired))
        {
            yError() << "[WalkingModule::updateModule] Error while setting the reference position to NAO.";
            return false;
        }
	
        m_profiler->setEndTime("Total");

        // print timings
        m_profiler->profiling();

        iDynTree::VectorDynSize errorL(6), errorR(6);
        if(m_useQPIK)
        {
            errorR = m_QPIKSolver->getRightFootError();
            errorL = m_QPIKSolver->getLeftFootError();
        }

        // send data to the WalkingLogger
        if(m_dumpData)
        {
            iDynTree::Vector2 desiredZMP;
            if(m_useMPC)
                desiredZMP = m_walkingController->getControllerOutput();
            else
                desiredZMP = m_walkingDCMReactiveController->getControllerOutput();

            auto leftFoot = m_FKSolver->getLeftFootToWorldTransform();
            auto rightFoot = m_FKSolver->getRightFootToWorldTransform();
            const iDynTree::Wrench& rightWrench = m_robotControlHelper->getRightWrench();
            const iDynTree::Wrench& leftWrench = m_robotControlHelper->getLeftWrench();
            
            //test
            
            
            
            
            m_walkingLogger->sendData(m_FKSolver->getDCM(), m_DCMPositionDesired.front(), m_DCMVelocityDesired.front(),
                                      measuredZMP, desiredZMP, m_FKSolver->getCoMPosition(),
                                      m_stableDCMModel->getCoMPosition(), yarp::sig::Vector(1, m_retargetingClient->comHeight()),
                                      m_stableDCMModel->getCoMVelocity(), yarp::sig::Vector(1, m_retargetingClient->comHeightVelocity()),
                                      leftFoot.getPosition(), leftFoot.getRotation().asRPY(),
                                      rightFoot.getPosition(), rightFoot.getRotation().asRPY(),
                                      m_leftTrajectory.front().getPosition(), m_leftTrajectory.front().getRotation().asRPY(),
                                      m_rightTrajectory.front().getPosition(), m_rightTrajectory.front().getRotation().asRPY(),
                                      m_robotControlHelper->getJointPosition(),
                                      m_qDesired,
rightWrench,
                                      leftWrench, Axy, aux_control, erro_n_output_pid, abs_CoM,
                                      torso_w, torso_tau,
                                      Lleg_w, Lleg_tau,
                                      Rleg_w, Rleg_tau,
                                      Larm_w, Larm_tau,
                                      Rarm_w, Rarm_tau
                                      
                                      
                                      );
        }







        // in the approaching phase the robot should not move and the trajectories should not advance
        if(!m_retargetingClient->isApproachingPhase())
        {
                propagateTime();

                // advance all the signals
                advanceReferenceSignals();
        }

        m_retargetingClient->setRobotBaseOrientation(yawRotation.inverse());
    }
    return true;
}

bool WalkingModule::evaluateZMP(iDynTree::Vector2& zmp)
{
    if(m_FKSolver == nullptr)
    {
        yError() << "[evaluateZMP] The FK solver is not ready.";
        return false;
    }

    iDynTree::Position zmpLeft, zmpRight, zmpWorld;
    zmpLeft.zero();
    zmpRight.zero();
    double zmpLeftDefined = 0.0, zmpRightDefined = 0.0;

    const iDynTree::Wrench& rightWrench = m_robotControlHelper->getRightWrench();
    if(rightWrench.getLinearVec3()(2) < 0.001)
        zmpRightDefined = 0.0;
    else
    {
        zmpRight(0) = -rightWrench.getAngularVec3()(1) / rightWrench.getLinearVec3()(2);
        zmpRight(1) = rightWrench.getAngularVec3()(0) / rightWrench.getLinearVec3()(2);
        zmpRight(2) = 0.0;
        zmpRightDefined = 1.0;
    }

    const iDynTree::Wrench& leftWrench = m_robotControlHelper->getLeftWrench();
    if(leftWrench.getLinearVec3()(2) < 0.001)
        zmpLeftDefined = 0.0;
    else
    {
        zmpLeft(0) = -leftWrench.getAngularVec3()(1) / leftWrench.getLinearVec3()(2);
        zmpLeft(1) = leftWrench.getAngularVec3()(0) / leftWrench.getLinearVec3()(2);
        zmpLeft(2) = 0.0;
        zmpLeftDefined = 1.0;
    }

    double totalZ = rightWrench.getLinearVec3()(2) + leftWrench.getLinearVec3()(2);
    if(totalZ < 0.1)
    {
        yError() << "[evaluateZMP] The total z-component of contact wrenches is too low.";
        yError() << "[evaluateZMP] The total z-component" <<totalZ;
        return false;
    }

    zmpLeft = m_FKSolver->getLeftFootToWorldTransform() * zmpLeft;
    zmpRight = m_FKSolver->getRightFootToWorldTransform() * zmpRight;

    // the global zmp is given by a weighted average
    iDynTree::toEigen(zmpWorld) = ((leftWrench.getLinearVec3()(2) * zmpLeftDefined) / totalZ)
        * iDynTree::toEigen(zmpLeft) +
        ((rightWrench.getLinearVec3()(2) * zmpRightDefined)/totalZ) * iDynTree::toEigen(zmpRight);

    zmp(0) = zmpWorld(0);
    zmp(1) = zmpWorld(1);

    return true;
}

bool WalkingModule::prepareRobot(bool onTheFly)
{
    if(m_robotState != WalkingFSM::Configured && m_robotState != WalkingFSM::Stopped)
    {
        yError() << "[WalkingModule::prepareRobot] The robot can be prepared only at the "
                 << "beginning or when the controller is stopped.";
        return false;
    }

    // get the current state of the robot
    // this is necessary because the trajectories for the joints, CoM height and neck orientation
    // depend on the current state of the robot
    if(!m_robotControlHelper->getFeedbacksRaw(100))
    {
        yError() << "[WalkingModule::prepareRobot] Unable to get the feedback.";
        return false;
    }

    if(onTheFly)
    {
        if(!m_FKSolver->setBaseOnTheFly())
        {
            yError() << "[WalkingModule::prepareRobot] Unable to set the onTheFly base.";
            return false;
        }

        if(!m_FKSolver->setInternalRobotState(m_robotControlHelper->getJointPosition(),
                                              m_robotControlHelper->getJointVelocity()))
        {
            yError() << "[WalkingModule::prepareRobot] Unable to set joint state.";
            return false;
        }

        // evaluate the left to right transformation, the inertial frame is on the left foot
        iDynTree::Transform leftToRightTransform = m_FKSolver->getRightFootToWorldTransform();

        // evaluate the first trajectory. The robot does not move!
        if(!generateFirstTrajectories(leftToRightTransform))
        {
            yError() << "[WalkingModule::prepareRobot] Failed to evaluate the first trajectories.";
            return false;
        }
    }
    else
    {
        // evaluate the first trajectory. The robot does not move! So the first trajectory
        if(!generateFirstTrajectories())
        {
            yError() << "[WalkingModule::prepareRobot] Failed to evaluate the first trajectories.";
            return false;
        }
    }

    // reset the gains
    if (m_robotControlHelper->getPIDHandler().usingGainScheduling())
    {
        if (!(m_robotControlHelper->getPIDHandler().reset()))
            return false;
    }

    if(!m_IKSolver->setFullModelFeedBack(m_robotControlHelper->getJointPosition()))
    {
        yError() << "[WalkingModule::prepareRobot] Error while setting the feedback to the IK solver.";
        return false;
    }

    iDynTree::Position desiredCoMPosition;
    desiredCoMPosition(0) = m_DCMPositionDesired.front()(0);
    desiredCoMPosition(1) = m_DCMPositionDesired.front()(1);
    desiredCoMPosition(2) = m_comHeightTrajectory.front();

    if(m_IKSolver->usingAdditionalRotationTarget())
    {
        // get the yow angle of both feet
        double yawLeft = m_leftTrajectory.front().getRotation().asRPY()(2);
        double yawRight = m_rightTrajectory.front().getRotation().asRPY()(2);

        // evaluate the mean of the angles
        double meanYaw = std::atan2(std::sin(yawLeft) + std::sin(yawRight),
                                    std::cos(yawLeft) + std::cos(yawRight));
        iDynTree::Rotation yawRotation, modifiedInertial;

        // it is important to notice that the inertial frames rotate with the robot
        yawRotation = iDynTree::Rotation::RotZ(meanYaw);

        yawRotation = yawRotation.inverse();
        modifiedInertial = yawRotation * m_inertial_R_worldFrame;

        if(!m_IKSolver->updateIntertiaToWorldFrameRotation(modifiedInertial))
        {
            yError() << "[WalkingModule::prepareRobot] Error updating the inertia to world frame rotation.";
            return false;
        }
    }

    if(!m_IKSolver->computeIK(m_leftTrajectory.front(), m_rightTrajectory.front(),
                              desiredCoMPosition, m_qDesired))
    {
        yError() << "[WalkingModule::prepareRobot] Inverse Kinematics failed while computing the initial position.";
        return false;
    }

    if(!m_robotControlHelper->setPositionReferences(m_qDesired, 5.0))
    {
        yError() << "[WalkingModule::prepareRobot] Error while setting the initial position.";
        return false;
    }

    {
        std::lock_guard<std::mutex> guard(m_mutex);
        m_robotState = WalkingFSM::Preparing;
    }

    return true;
}

bool WalkingModule::generateFirstTrajectories(const iDynTree::Transform &leftToRightTransform)
{
    if(m_trajectoryGenerator == nullptr)
    {
        yError() << "[WalkingModule::generateFirstTrajectories] Unicycle planner not available.";
        return false;
    }

    if(!m_trajectoryGenerator->generateFirstTrajectories(leftToRightTransform))
    {
        yError() << "[WalkingModule::generateFirstTrajectories] Failed while retrieving new trajectories from the unicycle";
        return false;
    }

    if(!updateTrajectories(0))
    {
        yError() << "[WalkingModule::generateFirstTrajectories] Unable to update the trajectory.";
        return false;
    }

    // reset the time
    m_time = 0.0;

    return true;
}

bool WalkingModule::generateFirstTrajectories()
{
    if(m_trajectoryGenerator == nullptr)
    {
        yError() << "[WalkingModule::generateFirstTrajectories] Unicycle planner not available.";
        return false;
    }

    if(m_robotControlHelper->isExternalRobotBaseUsed())
    {
        if(!m_trajectoryGenerator->generateFirstTrajectories(m_robotControlHelper->getBaseTransform().getPosition()))
        {
            yError() << "[WalkingModule::generateFirstTrajectories] Failed while retrieving new trajectories from the unicycle";
            return false;
        }
    }
    else
    {
        if(!m_trajectoryGenerator->generateFirstTrajectories())
        {
            yError() << "[WalkingModule::generateFirstTrajectories] Failed while retrieving new trajectories from the unicycle";
            return false;
        }
    }

    if(!updateTrajectories(0))
    {
        yError() << "[WalkingModule::generateFirstTrajectories] Unable to update the trajectory.";
        return false;
    }

    // reset the time
    m_time = 0.0;

    return true;
}

bool WalkingModule::askNewTrajectories(const double& initTime, const bool& isLeftSwinging,
                                       const iDynTree::Transform& measuredTransform,
                                       const size_t& mergePoint, const iDynTree::Vector2& desiredPosition)
{
    if(m_trajectoryGenerator == nullptr)
    {
        yError() << "[WalkingModule::askNewTrajectories] Unicycle planner not available.";
        return false;
    }

    if(mergePoint >= m_DCMPositionDesired.size())
    {
        yError() << "[WalkingModule::askNewTrajectories] The mergePoint has to be lower than the trajectory size.";
        return false;
    }

    if(!m_trajectoryGenerator->updateTrajectories(initTime, m_DCMPositionDesired[mergePoint],
                                                  m_DCMVelocityDesired[mergePoint], isLeftSwinging,
                                                  measuredTransform, desiredPosition))
    {
        yError() << "[WalkingModule::askNewTrajectories] Unable to update the trajectory.";
        return false;
    }
    return true;
}

bool WalkingModule::updateTrajectories(const size_t& mergePoint)
{
    if(!(m_trajectoryGenerator->isTrajectoryComputed()))
    {
        yError() << "[updateTrajectories] The trajectory is not computed.";
        return false;
    }

    std::vector<iDynTree::Transform> leftTrajectory;
    std::vector<iDynTree::Transform> rightTrajectory;
    std::vector<iDynTree::Twist> leftTwistTrajectory;
    std::vector<iDynTree::Twist> rightTwistTrajectory;
    std::vector<iDynTree::Vector2> DCMPositionDesired;
    std::vector<iDynTree::Vector2> DCMVelocityDesired;
    std::vector<bool> rightInContact;
    std::vector<bool> leftInContact;
    std::vector<double> comHeightTrajectory;
    std::vector<double> comHeightVelocity;
    std::vector<size_t> mergePoints;
    std::vector<bool> isLeftFixedFrame;
    std::vector<bool> isStancePhase;

    // get dcm position and velocity
    m_trajectoryGenerator->getDCMPositionTrajectory(DCMPositionDesired);
    m_trajectoryGenerator->getDCMVelocityTrajectory(DCMVelocityDesired);

    // get feet trajectories
    m_trajectoryGenerator->getFeetTrajectories(leftTrajectory, rightTrajectory);
    m_trajectoryGenerator->getFeetTwist(leftTwistTrajectory, rightTwistTrajectory);
    m_trajectoryGenerator->getFeetStandingPeriods(leftInContact, rightInContact);
    m_trajectoryGenerator->getWhenUseLeftAsFixed(isLeftFixedFrame);

    // get com height trajectory
    m_trajectoryGenerator->getCoMHeightTrajectory(comHeightTrajectory);
    m_trajectoryGenerator->getCoMHeightVelocity(comHeightVelocity);

    // get merge points
    m_trajectoryGenerator->getMergePoints(mergePoints);

    // get stance phase flags
    m_trajectoryGenerator->getIsStancePhase(isStancePhase);

    // append vectors to deques
    StdUtilities::appendVectorToDeque(leftTrajectory, m_leftTrajectory, mergePoint);
    StdUtilities::appendVectorToDeque(rightTrajectory, m_rightTrajectory, mergePoint);
    StdUtilities::appendVectorToDeque(leftTwistTrajectory, m_leftTwistTrajectory, mergePoint);
    StdUtilities::appendVectorToDeque(rightTwistTrajectory, m_rightTwistTrajectory, mergePoint);
    StdUtilities::appendVectorToDeque(isLeftFixedFrame, m_isLeftFixedFrame, mergePoint);

    StdUtilities::appendVectorToDeque(DCMPositionDesired, m_DCMPositionDesired, mergePoint);
    StdUtilities::appendVectorToDeque(DCMVelocityDesired, m_DCMVelocityDesired, mergePoint);

    StdUtilities::appendVectorToDeque(leftInContact, m_leftInContact, mergePoint);
    StdUtilities::appendVectorToDeque(rightInContact, m_rightInContact, mergePoint);

    StdUtilities::appendVectorToDeque(comHeightTrajectory, m_comHeightTrajectory, mergePoint);
    StdUtilities::appendVectorToDeque(comHeightVelocity, m_comHeightVelocity, mergePoint);

    StdUtilities::appendVectorToDeque(isStancePhase, m_isStancePhase, mergePoint);

    m_mergePoints.assign(mergePoints.begin(), mergePoints.end());

    // the first merge point is always equal to 0
    m_mergePoints.pop_front();

    return true;
}

bool WalkingModule::updateFKSolver()
{
    if(!m_robotControlHelper->isExternalRobotBaseUsed())
    {
        if(!m_FKSolver->evaluateWorldToBaseTransformation(m_leftTrajectory.front(),
                                                          m_rightTrajectory.front(),
                                                          m_isLeftFixedFrame.front()))
        {
            yError() << "[WalkingModule::updateFKSolver] Unable to evaluate the world to base transformation.";
            return false;
        }
    }
    else
    {
        m_FKSolver->evaluateWorldToBaseTransformation(m_robotControlHelper->getBaseTransform(),
                                                      m_robotControlHelper->getBaseTwist());

    }

    if(!m_FKSolver->setInternalRobotState(m_robotControlHelper->getJointPosition(),
                                          m_robotControlHelper->getJointVelocity()))
    {
        yError() << "[WalkingModule::updateFKSolver] Unable to set the robot state.";
        return false;
    }

    return true;
}

bool WalkingModule::startWalking()
{
    std::lock_guard<std::mutex> guard(m_mutex);

    if(m_robotState != WalkingFSM::Prepared && m_robotState != WalkingFSM::Paused)
    {
        yError() << "[WalkingModule::startWalking] Unable to start walking if the robot is not prepared or paused.";
        return false;
    }

    if(m_dumpData)
    {
        m_walkingLogger->startRecord({"record","dcm_x", "dcm_y",
                    "dcm_des_x", "dcm_des_y",
                    "dcm_des_dx", "dcm_des_dy",
                    "zmp_x", "zmp_y",
                    "zmp_des_x", "zmp_des_y",
                    "com_x", "com_y", "com_z",
                    "com_des_x", "com_des_y", "com_des_z",
                    "com_des_dx", "com_des_dy", "com_des_dz",
                    "lf_x", "lf_y", "lf_z",
                    "lf_roll", "lf_pitch", "lf_yaw",
                    "rf_x", "rf_y", "rf_z",
                    "rf_roll", "rf_pitch", "rf_yaw",
                    "lf_des_x", "lf_des_y", "lf_des_z",
                    "lf_des_roll", "lf_des_pitch", "lf_des_yaw",
                    "rf_des_x", "rf_des_y", "rf_des_z",
                    "rf_des_roll", "rf_des_pitch", "rf_des_yaw",
                    "LHipYawPitch", "RHipYawPitch",
                        "LShoulderPitch", "LShoulderRoll", "LElbowYaw", "LElbowRoll",
                        "RShoulderPitch", "RShoulderRoll", "RElbowYaw", "RElbowRoll",
                        "LHipPitch", "LHipRoll", "LKneePitch", "LAnklePitch", "LAnkleRoll",
                        "RHipPitch", "RHipRoll", "RKneePitch", "RAnklePitch", "RAnkleRoll",
                   "LHipYawPitch_des", "RHipYawPitch_des",
                        "LShoulderPitch_des", "LShoulderRoll_des", "LElbowYaw_des", "LElbowRoll_des",
                        "RShoulderPitch_des", "RShoulderRoll_des", "RElbowYaw_des", "RElbowRoll_des",
                        "LHipPitch_des", "LHipRoll_des", "LKneePitch_des", "LAnklePitch_des", "LAnkleRoll_des",
                        "RHipPitch_des", "RHipRoll_des", "RKneePitch_des", "RAnklePitch_des", "RAnkleRoll_des" ,"frx","fry","frz","mrx", "mry", "mrz", "flx", "fly", "flz", "mlx", "mly", "mlz","POS_X","POS_Y", "CONTROL_ORDER", "trash","e0","u0", "abs_CoM_x", "abs_CoM_y", "abs_CoM_z", 
                        
                        "torsowLHipYawPitch", "torsowRHipYawPitch", "torsotauLHipYawPitch", "torsotauRHipYawPitch",
                        "LLegwLHipPitch", "LLegwLHipRoll", "LLegwLKneePitch", "LLegwLAnklePitch", "LLegwLAnkleRoll", "trash",
                        "LLegtauLHipPitch", "LLegtauLHipRoll", "LLegtauLKneePitch", "LLegtauLAnklePitch", "LLegtauLAnkleRoll", "trash",
                        "RLegwRHipPitch", "RLegwRHipRoll", "RLegwRKneePitch", "RLegwRAnklePitch", "RLegwRAnkleRoll", "trash",
                        "RLegtauRHipPitch", "RLegtauRHipRoll", "RLegtauRKneePitch", "RLegtauRAnklePitch", "RLegtauRAnkleRoll", "trash",
                        "LArmwLShoulderPitch", "LArmwLShoulderRoll", "LArmwLElbowYaw", "LArmwLElbowRoll",
                        "LArmtauLShoulderPitch", "LArmtauLShoulderRoll", "LArmtauLElbowYaw", "LArmtauLElbowRoll",
                        "RArmwRShoulderPitch", "RArmwRShoulderRoll", "RArmwRElbowYaw", "RArmwRElbowRoll",
                        "RArmtauRShoulderPitch", "RArmtauRShoulderRoll", "RArmtauRElbowYaw", "RArmtauRElbowRoll"
                         });
    }


        
        
        
    // if the robot was only prepared the filters has to be reseted
    if(m_robotState == WalkingFSM::Prepared)
    {
        m_robotControlHelper->resetFilters();

        updateFKSolver();

         if (m_robotControlHelper->isExternalRobotBaseUsed())
         {
             double heightOffset = (m_FKSolver->getLeftFootToWorldTransform().getPosition()(2)
                                    + m_FKSolver->getRightFootToWorldTransform().getPosition()(2)) / 2;
             m_robotControlHelper->setHeightOffset(heightOffset);
         }

     }

    if (!m_robotControlHelper->loadCustomInteractionMode())
    {
        yError() << "[WalkingModule::startWalking] Unable to set the intraction mode of the joints";
        return false;
    }

    // before running the controller the retargeting client goes in approaching phase this
    // guarantees a smooth transition
    m_retargetingClient->setPhase(RetargetingClient::Phase::approacing);
    m_robotState = WalkingFSM::Walking;

    return true;
}

bool WalkingModule::setPlannerInput(double x, double y)
{
    // in the approaching phase the robot should not move
    // as soon as the approaching phase is finished the user
    // can move the robot
    if(m_retargetingClient->isApproachingPhase())
        return true;

    // the trajectory was already finished the new trajectory will be attached as soon as possible
    if(m_mergePoints.empty())
    {
        if(!(m_leftInContact.front() && m_rightInContact.front()))
        {
            yError() << "[WalkingModule::setPlannerInput] The trajectory has already finished but the system is not in double support.";
            return false;
        }

        if(m_newTrajectoryRequired)
            return true;

        // Since the evaluation of a new trajectory takes time the new trajectory will be merged after x cycles
        m_newTrajectoryMergeCounter = 20;
    }

    // the trajectory was not finished the new trajectory will be attached at the next merge point
    else
    {
        if(m_mergePoints.front() > 20)
            m_newTrajectoryMergeCounter = m_mergePoints.front();
        else if(m_mergePoints.size() > 1)
        {
            if(m_newTrajectoryRequired)
                return true;

            m_newTrajectoryMergeCounter = m_mergePoints[1];
        }
        else
        {
            if(m_newTrajectoryRequired)
                return true;

            m_newTrajectoryMergeCounter = 20;
        }
    }

    m_desiredPosition(0) = x;
    m_desiredPosition(1) = y;

    m_newTrajectoryRequired = true;

    return true;
}

bool WalkingModule::setGoal(double x, double y)
{
    std::lock_guard<std::mutex> guard(m_mutex);
    
    if(m_robotState != WalkingFSM::Walking)
        return false;
        // aux
    x_pos_ordered = x;
    ini_yaw_aux =1;
    return setPlannerInput(x, y);
}

bool WalkingModule::pauseWalking()
{
    std::lock_guard<std::mutex> guard(m_mutex);

    if(m_robotState != WalkingFSM::Walking)
        return false;

    // close the logger
    if(m_dumpData)
        m_walkingLogger->quit();

    m_robotState = WalkingFSM::Paused;
    return true;
}

bool WalkingModule::stopWalking()
{
    std::lock_guard<std::mutex> guard(m_mutex);

    if(m_robotState != WalkingFSM::Walking)
        return false;

    reset();

    m_robotState = WalkingFSM::Stopped;
    return true;
}
