#!/bin/bash

echo "0.0 0.0 0.0 0.0 0.0 0.0" | yarp write ... /iCubGui/base:i 

echo "!!iCub lifted in the GUI!!"
